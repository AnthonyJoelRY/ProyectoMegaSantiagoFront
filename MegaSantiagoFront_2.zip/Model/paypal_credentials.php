<?php
// Model/paypal_credentials.php
// ⚠️ Usa credenciales de SANDBOX (Developer Dashboard). No subas tus credenciales reales a repos públicos.
$paypal_mode = "sandbox"; // "sandbox" | "live"

// Reemplaza por tu Client ID / Secret de PayPal (SANDBOX)
$paypal_client_id = "PAYPAL_SANDBOX_CLIENT_ID";
$paypal_client_secret = "PAYPAL_SANDBOX_CLIENT_SECRET";

// Moneda por defecto para los pagos
$paypal_currency = "USD";
?>
