<script src="/MegaSantiagoFront/Model/js/busqueda-global.js"></script>
<script src="/MegaSantiagoFront/Model/js/sesion-usuario.js"></script>

