<?php
// Model/paypal_credentials.php
// ⚠️ Usa credenciales de SANDBOX (Developer Dashboard). No subas tus credenciales reales a repos públicos.
$paypal_mode = "sandbox"; // "sandbox" | "live"

// Reemplaza por tu Client ID / Secret de PayPal (SANDBOX)
$paypal_client_id = "Ae99qRpbob6Zy_i3qEiH7rvPuRn78_yvFEW0H-TmBiOJYazlaYIzq_x1L6twidEt9Z25yyW-Y3_W8W5c";
$paypal_client_secret = "EFsSYdlugjyuoc-llM7A56fMsT8Ty8gQaezgXVo-1nrYRwomA683-26LhxdFWWJab_Wgh7bEwxdJHZKr";

// Moneda por defecto para los pagos
$paypal_currency = "USD";
?>
