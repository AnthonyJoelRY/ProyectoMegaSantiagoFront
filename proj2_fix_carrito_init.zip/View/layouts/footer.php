<footer class="footer">
  <p>MegaSantiago © 2025 - Todos los derechos reservados</p>
</footer>
